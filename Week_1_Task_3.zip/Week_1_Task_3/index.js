'use strict';

const path = require('path');
const express = require('express');

const app = express();

app.use(express.static(path.join(__dirname, 'images')));
app.use(express.static(path.join(__dirname, 'views')));
app.set('views', (path.join(__dirname, 'views')));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.render('die', {
        value: 1
    })
});

app.get('/:value*', (req, res) => {
    var a = req.params.value;
    if (0 < a < 7) {
        res.render('die', {
            value: a
        });
    }
    else {
        res.send('Error, Something went wrong!!!!');
    }
});

app.listen(3000);
