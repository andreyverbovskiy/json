'use strict';
const http = require('http');
const fs = require('fs');
const express = require('express');
const path = require('path');
const os = require('os');
let Port;
Port = 3000;
const app = express();
app.use(express.static(path.join(__dirname, '.')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'))
})
app.get('/memory', (req, res) => {
    let data = [{"freemem": os.freemem(), "totalmem": os.totalmem(),}];
    res.status(200)
        .contentType("application/json")
        .send(data);
})

app.listen(Port);