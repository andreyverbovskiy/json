'use strict';
const bytes = document.querySelector('#bytes');
const KB = document.querySelector('#KB');
const MB = document.querySelector('#MB');
const GB = document.querySelector('#GB');
const RAM = document.querySelector('#RAM');
const relative = document.querySelector('#rel');
const FREE = document.querySelector('#free');

let coef = 1;

const memory = async () => {
	let req = new XMLHttpRequest();
	req.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {

			const json = JSON.parse(req.response);

			let ram = (parseInt(json[0].totalmem) / coef).toFixed(2);
			let use = ((parseInt(json[0].totalmem) - parseInt(json[0].freemem)) / coef).toFixed(2);
			let free = (parseInt(json[0].freemem)/coef).toFixed(2);

			RAM.innerHTML = use;
			FREE.innerHTML = free;

			let rel = ((use / ram) * 100).toFixed(0);

			relative.innerHTML = rel + '%';

			if (rel <= 60) {
				relative.className = "green";
			}
			else if (60 < rel <= 80) {
				relative.className = "black";
			}
			else if ( 80 < rel <= 90) {
				relative.className = "orange";
			}
			else {
				relative.className = "red";
			}
		}
	};
	req.open("GET", "memory", true);
	req.send();
}

bytes.addEventListener('click', async => {
	if (coef != 1) {
		coef = 1;
	}
})

KB.addEventListener('click', async (evt) => {
	if (coef != 1024){
		coef = 1024;     //or 1000 ???
	}
});

MB.addEventListener('click', async (evt) => {
	if (coef != 1048576){
		coef = 1048576;  //or 1000000 ???
	}
});

GB.addEventListener('click', async (evt) => {
	if (coef != 1073741824){
		coef = 1073741824;  //or 1000000000 ???
	}
});

setInterval(memory,1000);


