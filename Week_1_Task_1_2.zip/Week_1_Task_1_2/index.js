const http = require('http');
const fs = require('fs')
Port = 3000
const path = require('path');
const app = require('express')()
const express = require('express');


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'))
});

app.get('/:name', (req, res) => {
    res.sendFile(path.join(__dirname, 'age.html'))
    let name = req.params.name;
    let age = req.query.age;

    if (age === undefined) {             //ask age if it was not defined before
        res.sendFile(path.join(__dirname, 'age.html'));
    }
    else if (age < 18) {
        res.send("This page was designed for adults, go play Fortnite " + name + "!");
    }
    else if (age >= 18) {
        res.send("Welcome to PornHub, " + name + "!");
    }
});

app.get('/:name*', (req, res) => {

    res.sendFile(path.join(__dirname, 'age.html'));
});
// The rest of the routes goes here

app.listen(Port);
